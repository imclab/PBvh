package pbvh;

public class PBvhJoint {
	PBvhJoint(){
		
	}
}
